
document.getElementById("form-registro").addEventListener("submit", function(e) {
  e.preventDefault();
  const nombre = document.getElementById("nombre").value;
  const distrito = document.getElementById("distrito").value;
  const mensajesDiv = document.getElementById("mensajes");

  const nuevoMensaje = document.createElement("div");
  nuevoMensaje.textContent = `${nombre} (${distrito}) se unió a la comunidad.`;
  mensajesDiv.appendChild(nuevoMensaje);

  this.reset();
});

// Chart de horarios ficticio
window.addEventListener("load", () => {
  const ctx = document.getElementById('horarioChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Castilla', 'Centro', 'Santa Julia', 'Veintiséis de Octubre'],
      datasets: [{
        label: 'Hora de recolección (24h)',
        data: [6, 8, 7, 9],
        backgroundColor: '#00acc1'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
});
